import streamlit as st
from dotenv import load_dotenv
from modules.user_input_handler import handle_userinput
from modules.chat_history_display import display_chat_history
from modules.pdf_processing import get_pdf_text, get_text_chunks
from modules.vectorstore_chain import get_vectorstore, get_conversation_chain
from templates.css import css
from templates.htmlTemplates import bot_template, user_template
import base64

# Load environment variables
load_dotenv()

def encode_pdf_base64(pdf):
    """Encodes a PDF file to base64 for embedding in an iframe."""
    try:
        base64_pdf = base64.b64encode(pdf.getvalue()).decode("utf-8")
        return f"data:application/pdf;base64,{base64_pdf}"
    except AttributeError:
        st.error("Failed to encode PDF. Ensure the file is uploaded and valid.")
        return None

def display_pdf_with_iframe(base64_pdf):
    """Displays a PDF using an iframe in Streamlit."""
    if base64_pdf:
        pdf_display = f'<iframe src="{base64_pdf}" width="700" height="900" type="application/pdf"></iframe>'
        st.markdown(pdf_display, unsafe_allow_html=True)
    else:
        st.error("No PDF available for display.")

def main():
    st.set_page_config(page_title="Chat with multiple PDFs", page_icon=":books:")
    st.write(css, unsafe_allow_html=True)

    # Initialize session state variables
    for key in ["conversation", "chat_history", "questions_by_date", "user_question", "selected_question", "uploaded_pdfs"]:
        if key not in st.session_state:
            st.session_state[key] = None if key == "conversation" else [] if key in ["chat_history", "uploaded_pdfs"] else ""

    st.header("Ask Anything About Your Uploaded PDFs")

    # Sidebar for uploading or selecting files
    with st.sidebar:
        st.title('✨ Converse AI \ud83d\udde8\ufe0f\nChat with multiple PDFs :books:')
        source_option = st.radio("Select Upload Source", ('Browser', 'SharePoint'))

        if source_option == 'Browser':
            pdf_docs = st.file_uploader("Upload your PDFs here and click on 'Process'", accept_multiple_files=True)
            if pdf_docs:
                st.session_state.uploaded_pdfs = pdf_docs

        elif source_option == 'SharePoint':
            st.subheader("Enter SharePoint details:")
            sharepoint_url = st.text_input("SharePoint Site URL")
            sharepoint_path = st.text_input("SharePoint Path")
            sharepoint_username = st.text_input("SharePoint Username")
            sharepoint_password = st.text_input("SharePoint Password", type="password")

        if st.button("Process"):
            with st.spinner("Processing..."):
                raw_text = ""
                if source_option == 'Browser' and st.session_state.uploaded_pdfs:
                    raw_text = get_pdf_text(st.session_state.uploaded_pdfs)
                    # Encode the uploaded PDF to Base64
                    base64_pdf = encode_pdf_base64(st.session_state.uploaded_pdfs[0])
                    st.write(f"Encoded PDF Base64 (first 100 characters): {base64_pdf[:100]}...")
                    # Display the uploaded PDF in an iframe
                    display_pdf_with_iframe(st.session_state.uploaded_pdfs[0])

                elif source_option == 'SharePoint' and sharepoint_url and sharepoint_path:
                    # Placeholder for SharePoint processing logic
                    st.write(f"Processing SharePoint PDF from {sharepoint_url}...")

                if raw_text:
                    text_chunks = get_text_chunks(raw_text)
                    vectorstore = get_vectorstore(text_chunks)
                    st.session_state.conversation = get_conversation_chain(vectorstore)
                    st.success("Processing completed!")
                else:
                    st.warning("No content found to process.")

    # Display conversation history using the custom HTML templates
    if st.session_state.questions_by_date:
        for date, qa_pairs in st.session_state.questions_by_date.items():
            for qa_pair in qa_pairs:
                st.write(user_template.replace("{{MSG}}", qa_pair["user"]), unsafe_allow_html=True)
                st.write(bot_template.replace("{{MSG}}", qa_pair["bot"]), unsafe_allow_html=True)

    # Input box for new questions
    if st.session_state.selected_question == "":
        st.text_input(
            label="",
            placeholder="Enter Your Query Prompt:",
            key="user_question",
            on_change=handle_userinput
        )
    else:
        st.write(user_template.replace("{{MSG}}", st.session_state.selected_question), unsafe_allow_html=True)
        st.write(bot_template.replace("{{MSG}}", st.session_state.chat_history), unsafe_allow_html=True)

    # Chat history section
    display_chat_history()

if __name__ == '__main__':
    main()

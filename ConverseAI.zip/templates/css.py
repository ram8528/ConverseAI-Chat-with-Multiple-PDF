def load_css():
    css_styles = """
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
        }
        .stButton>button {
            background-color: #007BFF;
            color: white;
            border-radius: 5px;
            padding: 0.5em 1em;
            border: none;
        }
        .stButton>button:hover {
            background-color: #0056b3;
            color: white;
        }
        .stTextArea textarea {
            border-radius: 5px;
            border: 1px solid #ccc;
            padding: 0.5em;
        }
        .stMarkdown h1, h2, h3, h4, h5, h6 {
            color: #007BFF;
        }
        .sidebar .sidebar-content {
            background-color: #ffffff;
            padding: 1em;
        }
        a {
            color: #007BFF;
            text-decoration: none;
        }
        a:hover {
            color: #0056b3;
            text-decoration: underline;
        }
    </style>
    """
    return css_styles

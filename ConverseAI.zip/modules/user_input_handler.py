import streamlit as st
from datetime import datetime
from pdf_processing import encode_pdf_base64

def handle_userinput():
    user_question = st.session_state.user_question

    if st.session_state.conversation is not None and user_question:
        response = st.session_state.conversation({'question': user_question})
        st.session_state.chat_history = response['chat_history']

        sources = []
        if 'source_documents' in response:
            for doc in response['source_documents']:
                if 'references' in doc.metadata:
                    references = doc.metadata['references']
                    for ref in references:
                        page_number = ref.split("Page ")[1]
                        pdf_index = doc.metadata['pdf_index']
                        base64_pdf = encode_pdf_base64(st.session_state.uploaded_pdfs[pdf_index])
                        pdf_link = f"<a href='{base64_pdf}' target='_blank' style='text-decoration:none;color:blue;'>Page {page_number}</a>"
                        sources.append(pdf_link)
        
        last_response = response['chat_history'][-1].content
        formatted_response = f"{last_response}\n\n**References:**\n" + "\n".join(sources)

        current_date = datetime.now().strftime('%Y-%m-%d')
        if current_date not in st.session_state.questions_by_date:
            st.session_state.questions_by_date[current_date] = []

        st.session_state.questions_by_date[current_date].append({
            "user": user_question,
            "bot": formatted_response
        })

        st.session_state.user_question = ""
import base64
import streamlit as st
from PyPDF2 import PdfReader

def encode_pdf_base64(pdf):
    """Encodes a PDF file to base64 for embedding in an iframe."""
    try:
        base64_pdf = base64.b64encode(pdf.getvalue()).decode("utf-8")
        return f"data:application/pdf;base64,{base64_pdf}"
    except AttributeError:
        st.error("Failed to encode PDF. Ensure the file is uploaded and valid.")
        return None

def display_pdf_with_iframe(base64_pdf):
    """Displays a PDF using an iframe in Streamlit."""
    if base64_pdf:
        pdf_display = f'<iframe src="{base64_pdf}" width="700" height="900" type="application/pdf"></iframe>'
        st.markdown(pdf_display, unsafe_allow_html=True)
    else:
        st.error("No PDF available for display.")


def get_pdf_text(pdf_docs):
    pdf_data = []
    for pdf_index, pdf in enumerate(pdf_docs):
        pdf_reader = PdfReader(pdf)
        for page_num, page in enumerate(pdf_reader.pages, start=1):
            lines = page.extract_text().split("\n")
            for line_num, line in enumerate(lines, start=1):
                pdf_data.append({
                    "pdf_index": pdf_index,
                    "page": page_num,
                    "line": line_num,
                    "content": line
                })
    return pdf_data

def get_text_chunks(pdf_data):
    text_chunks = []
    chunk_content = ""
    chunk_references = []

    for ref in pdf_data:
        chunk_content += ref["content"] + "\n"
        chunk_references.append(f"Page {ref['page']}, Line {ref['line']}")

        if len(chunk_content) >= 1000:
            text_chunks.append({"content": chunk_content.strip(), "references": chunk_references})
            chunk_content = ""
            chunk_references = []

    if chunk_content:
        text_chunks.append({"content": chunk_content.strip(), "references": chunk_references})

    return text_chunks
import streamlit as st
from datetime import datetime, timedelta

def display_chat_history():
    today = datetime.now().strftime('%Y-%m-%d')
    yesterday = (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d')
    day_before_yesterday = (datetime.now() - timedelta(days=2)).strftime('%Y-%m-%d')

    if today in st.session_state.questions_by_date:
        st.sidebar.subheader("Today's History")
        for i, qa_pair in enumerate(st.session_state.questions_by_date[today]):
            if st.sidebar.button(f"Q{i + 1}: {qa_pair['user'][:30]}..."):
                st.session_state.selected_question = qa_pair["user"]
                st.session_state.chat_history = qa_pair["bot"]
                break

    if yesterday in st.session_state.questions_by_date:
        st.sidebar.subheader("Yesterday's History")
        for i, qa_pair in enumerate(st.session_state.questions_by_date[yesterday]):
            if st.sidebar.button(f"Q{i + 1}: {qa_pair['user'][:30]}..."):
                st.session_state.selected_question = qa_pair["user"]
                st.session_state.chat_history = qa_pair["bot"]
                break

    if day_before_yesterday in st.session_state.questions_by_date:
        st.sidebar.subheader("Day Before Yesterday's History")
        for i, qa_pair in enumerate(st.session_state.questions_by_date[day_before_yesterday]):
            if st.sidebar.button(f"Q{i + 1}: {qa_pair['user'][:30]}..."):
                st.session_state.selected_question = qa_pair["user"]
                st.session_state.chat_history = qa_pair["bot"]
                break